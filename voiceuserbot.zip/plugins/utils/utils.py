from sys import version_info


modules_help = {}
requirements_list = []

github = '<a href=https://github.com/JoHn-111/Dragon-Userbot> github</a>'
license = '<a href=https://github.com/JoHn-111/Dragon-Userbot/blob/master/LICENSE> GNU General Public License v3.0</a>'
copyright = '© <a href=https://github.com/JoHn-111>John</a>, 2021'
python_version = f"{version_info[0]}.{version_info[1]}.{version_info[2]}"
