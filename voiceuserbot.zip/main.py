from pyrogram import Client


app = Client("my_account")

if __name__ == '__main__':
    app.run()
